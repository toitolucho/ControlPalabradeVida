import org.quarkbit.controlpalabravida.formularios.FAutenticacion;


public class ControlPalabraVida {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FAutenticacion formAutenticacion = new FAutenticacion();
		formAutenticacion.setVisible(true);
	}

}
