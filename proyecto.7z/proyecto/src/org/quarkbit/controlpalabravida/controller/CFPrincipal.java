package org.quarkbit.controlpalabravida.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

import org.apache.ibatis.session.SqlSession;
import org.quarkbit.controlpalabravida.dao.domain.Usuario;
import org.quarkbit.controlpalabravida.formularios.FPrincipal;

public class CFPrincipal implements ActionListener {
	public FPrincipal formPrincipal;
	private Date fechaHoraServidor;
	private Usuario usuario;
	 private SqlSession session;
	 
	 
	 
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub

	}
	
	public CFPrincipal(FPrincipal formPrincipal)
	{
		this.formPrincipal = formPrincipal;
	}
	
	public void onFormShown()
	{
		
	}

	public Date getFechaHoraServidor() {
		return fechaHoraServidor;
	}

	public void setFechaHoraServidor(Date fechaHoraServidor) {
		this.fechaHoraServidor = fechaHoraServidor;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public SqlSession getSession() {
		return session;
	}

	public void setSession(SqlSession session) {
		this.session = session;
	}
	
	
	

}
